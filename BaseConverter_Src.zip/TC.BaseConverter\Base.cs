using System;
using System.Collections.Generic;
using System.Text;

namespace TC.BaseConverter
{
	enum Base
	{
		None = 0,
		Binary,
		Octal,
		Decimal,
		Hexadecimal
	}
}
